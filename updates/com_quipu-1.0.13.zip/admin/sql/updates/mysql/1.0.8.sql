ALTER TABLE  `#__quipu_config` ADD  `sync` TEXT NOT NULL;
ALTER TABLE  `#__quipu_config` ADD  `currency_symbol` CHAR( 10 ) NOT NULL;